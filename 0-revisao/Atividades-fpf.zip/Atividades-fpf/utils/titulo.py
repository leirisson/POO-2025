


def titulo(titulo: str) -> None:
    print(titulo.upper())