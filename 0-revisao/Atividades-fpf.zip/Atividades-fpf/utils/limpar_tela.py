import os


def limpar_tela() -> None:
    os.system("cls")